/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package me.junit1;

/**
 *
 * @author idmig
 */
public class JUnit1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
