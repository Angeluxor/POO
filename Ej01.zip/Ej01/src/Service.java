
/*Diseñar un programa que lea y guarde razas de perros en un ArrayList de tipo String. El
programa pedirá una raza de perro en un bucle, el mismo se guardará en la lista y
después se le preguntará al usuario si quiere guardar otro perro o si quiere salir. Si decide
salir, se mostrará todos los perros guardados en el ArrayList.*/

import java.util.ArrayList;
import java.util.Scanner;

public class Service {
    ArrayList<String> arrayRaza = new ArrayList<>();
    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public void crearRaza() {
        boolean opcion;
        do {
            System.out.println("Ingrese la raza plis: ");
            arrayRaza.add(leer.next());
            System.out.println("Desea agregar mas razas? S/N");
            opcion = (leer.next().equalsIgnoreCase("S"));
            System.out.println(opcion);

        } while (opcion);

        System.out.println(arrayRaza.toString());


    }
}