/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package me.tiendaelectrodomesticos;

/**
 *
 * @author idmig
 */
public class TiendaElectrodomesticos {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
