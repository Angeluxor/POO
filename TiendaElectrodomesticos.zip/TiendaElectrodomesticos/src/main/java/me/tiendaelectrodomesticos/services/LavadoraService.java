/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package me.tiendaelectrodomesticos.services;

/**
 *
 * @author idmig
 */
public class LavadoraService extends ElectrodomesticoService{
    
 public static void crearLavadora(){
   
 }
    
    
}
